import java.util.Queue;
import java.util.LinkedList;

    class Paciente {
    String nome;
    int idade;

    Paciente(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
}

    public class EX2 {
    public static void main(String[] args) {

        Queue<Paciente> fila = new LinkedList<>();

        fila.add(new Paciente("Maria", 25));
        fila.add(new Paciente("Joao", 40));
        fila.add(new Paciente("Ana", 32));

        for (Paciente p : fila) {
            System.out.println("Nome: " + p.nome);
            System.out.println("Idade: " + p.idade);
            System.out.println();
        }
    }
}
