
import java.util.LinkedList;

class Veiculo {
    String marca;
    int anoFabricacao;

    Veiculo(String marca, int ano) {
        this.marca = marca;
        this.anoFabricacao = ano;
    }
}

class Carro extends Veiculo {
    String tipoCombustivel;

    Carro(String marca, int ano, String combustivel) {
        super(marca, ano);
        tipoCombustivel = combustivel;
    }
}

class Moto extends Veiculo {
    int potenciaMotor;

    Moto(String marca, int ano, int potencia) {
        super(marca, ano);
        potenciaMotor = potencia;
    }
}

public class EX1 {
    public static void main(String[] args) {

        LinkedList<Veiculo> lista = new LinkedList<>();

        lista.add(new Carro("Fiat", 2020, "Flex"));
        lista.add(new Carro("Toyota", 2022, "Gasolina"));
        lista.add(new Moto("Honda", 2023, 160));
        lista.add(new Moto("Yamaha", 2024, 150));

        int carros = 0;
        int motos = 0;

        for (Veiculo v : lista) {
            if (v instanceof Carro) {
                carros++;
            } else if (v instanceof Moto) {
                motos++;
            }
        }

        System.out.println("Carros: " + carros);
        System.out.println("Motos: " + motos);
    }
}
