import java.util.Stack;
import java.util.HashMap;

    class Prato {
    String cor;

    Prato(String cor) {
        this.cor = cor;
    }
}

    public class EX3 {
    public static void main(String[] args) {

        Stack<Prato> pilha = new Stack<>();

        pilha.push(new Prato("Branco"));
        pilha.push(new Prato("Rosa"));
        pilha.push(new Prato("Branco"));
        pilha.push(new Prato("Azul"));
        pilha.push(new Prato("Rosa"));
        pilha.push(new Prato("Branco"));

        HashMap<String, Integer> cores = new HashMap<>();

        for (Prato p : pilha) {
            if (cores.containsKey(p.cor)) {
                cores.put(p.cor, cores.get(p.cor) + 1);
            } else {
                cores.put(p.cor, 1);
            }
        }

        for (String cor : cores.keySet()) {
            System.out.println(cor + " -> " + cores.get(cor) + " pratos");
        }
    }
}
